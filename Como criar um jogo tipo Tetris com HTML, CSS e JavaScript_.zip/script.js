const canvas = document.getElementById("tetris");
const context = canvas.getContext("2d");
const scoreElement = document.getElementById("score");

const ROW = 20;
const COL = 10;
const SQ = canvas.width / COL; // Tamanho de um quadrado
const VACANT = "#ddd"; // Cor de um quadrado vazio

// Desenha um quadrado
function drawSquare(x, y, color) {
    context.fillStyle = color;
    context.fillRect(x * SQ, y * SQ, SQ, SQ);

    context.strokeStyle = "#333"; // Cor da borda
    context.strokeRect(x * SQ, y * SQ, SQ, SQ);
}

// Cria o tabuleiro
let board = [];
for (let r = 0; r < ROW; r++) {
    board[r] = [];
    for (let c = 0; c < COL; c++) {
        board[r][c] = VACANT;
    }
}

// Desenha o tabuleiro
function drawBoard() {
    for (let r = 0; r < ROW; r++) {
        for (let c = 0; c < COL; c++) {
            drawSquare(c, r, board[r][c]);
        }
    }
}

drawBoard();

// Define as formas dos Tetrominós
const Z = [
    [[1, 1, 0],
     [0, 1, 1],
     [0, 0, 0]],
    [[0, 0, 1],
     [0, 1, 1],
     [0, 1, 0]]
];

const S = [
    [[0, 1, 1],
     [1, 1, 0],
     [0, 0, 0]],
    [[0, 1, 0],
     [0, 1, 1],
     [0, 0, 1]]
];

const T = [
    [[0, 1, 0],
     [1, 1, 1],
     [0, 0, 0]],
    [[0, 1, 0],
     [0, 1, 1],
     [0, 1, 0]],
    [[0, 0, 0],
     [1, 1, 1],
     [0, 1, 0]],
    [[0, 1, 0],
     [1, 1, 0],
     [0, 1, 0]]
];

const O = [
    [[1, 1],
     [1, 1]]
];

const L = [
    [[0, 0, 1],
     [1, 1, 1],
     [0, 0, 0]],
    [[0, 1, 0],
     [0, 1, 0],
     [0, 1, 1]],
    [[0, 0, 0],
     [1, 1, 1],
     [1, 0, 0]],
    [[1, 1, 0],
     [0, 1, 0],
     [0, 1, 0]]
];

const I = [
    [[0, 0, 0, 0],
     [1, 1, 1, 1],
     [0, 0, 0, 0],
     [0, 0, 0, 0]],
    [[0, 1, 0, 0],
     [0, 1, 0, 0],
     [0, 1, 0, 0],
     [0, 1, 0, 0]]
];

const J = [
    [[1, 0, 0],
     [1, 1, 1],
     [0, 0, 0]],
    [[0, 1, 1],
     [0, 1, 0],
     [0, 1, 0]],
    [[0, 0, 0],
     [1, 1, 1],
     [0, 0, 1]],
    [[0, 1, 0],
     [0, 1, 0],
     [1, 1, 0]]
];

// As peças e suas cores
const PIECES = [
    [Z, "red"],
    [S, "green"],
    [T, "yellow"],
    [O, "blue"],
    [L, "purple"],
    [I, "cyan"],
    [J, "orange"]
];

// Gera peças aleatórias
function randomPiece() {
    let r = Math.floor(Math.random() * PIECES.length); // 0 -> 6
    return new Piece(PIECES[r][0], PIECES[r][1]);
}

// O Objeto Peça
function Piece(tetromino, color) {
    this.tetromino = tetromino;
    this.color = color;

    this.tetrominoN = 0; // Começa com o primeiro padrão
    this.activeTetromino = this.tetromino[this.tetrominoN];

    // Posição inicial padrão
    this.x = 3;
    this.y = -2; // Começa um pouco acima do tabuleiro visível
}

// Função de preenchimento
Piece.prototype.fill = function(color) {
    for (let r = 0; r < this.activeTetromino.length; r++) {
        for (let c = 0; c < this.activeTetromino.length; c++) {
            // Desenha apenas quadrados ocupados
            if (this.activeTetromino[r][c]) {
                drawSquare(this.x + c, this.y + r, color);
            }
        }
    }
}

// Desenha uma peça no tabuleiro
Piece.prototype.draw = function() {
    this.fill(this.color);
}

// Apaga uma peça (preenche com a cor vaga)
Piece.prototype.unDraw = function() {
    this.fill(VACANT);
}

// Move a peça para baixo
Piece.prototype.moveDown = function() {
    if (!this.collision(0, 1, this.activeTetromino)) {
        this.unDraw();
        this.y++;
        this.draw();
    } else {
        // Bloqueia a peça e gera uma nova
        this.lock();
        p = randomPiece();
    }
}

// Move a peça para a direita
Piece.prototype.moveRight = function() {
    if (!this.collision(1, 0, this.activeTetromino)) {
        this.unDraw();
        this.x++;
        this.draw();
    }
}

// Move a peça para a esquerda
Piece.prototype.moveLeft = function() {
    if (!this.collision(-1, 0, this.activeTetromino)) {
        this.unDraw();
        this.x--;
        this.draw();
    }
}

// Roda a peça
Piece.prototype.rotate = function() {
    let nextPattern = this.tetromino[(this.tetrominoN + 1) % this.tetromino.length];
    let kick = 0;

    if (this.collision(0, 0, nextPattern)) {
        if (this.x > COL / 2) {
            // É a parede direita
            kick = -1; // Move a peça um passo para a esquerda
        } else {
            // É a parede esquerda
            kick = 1; // Move a peça um passo para a direita
        }
    }

    if (!this.collision(kick, 0, nextPattern)) {
        this.unDraw();
        this.x += kick;
        this.tetrominoN = (this.tetrominoN + 1) % this.tetromino.length;
        this.activeTetromino = this.tetromino[this.tetrominoN];
        this.draw();
    }
}

let score = 0;

Piece.prototype.lock = function() {
    for (let r = 0; r < this.activeTetromino.length; r++) {
        for (let c = 0; c < this.activeTetromino.length; c++) {
            // Pula os quadrados vagos
            if (!this.activeTetromino[r][c]) {
                continue;
            }
            // Peças a bloquear no topo = fim de jogo
            if (this.y + r < 0) {
                alert("Game Over");
                // Para requestAnimationFrame
                gameOver = true;
                break;
            }
            // Bloqueia a peça
            board[this.y + r][this.x + c] = this.color;
        }
    }
    // Remove linhas completas
    for (let r = 0; r < ROW; r++) {
        let isRowFull = true;
        for (let c = 0; c < COL; c++) {
            isRowFull = isRowFull && (board[r][c] != VACANT);
        }
        if (isRowFull) {
            // Se a linha está completa
            // Move todas as linhas acima dela para baixo
            for (let y = r; y > 1; y--) {
                for (let c = 0; c < COL; c++) {
                    board[y][c] = board[y - 1][c];
                }
            }
            // A linha superior board[0][..] não tem linha acima
            for (let c = 0; c < COL; c++) {
                board[0][c] = VACANT;
            }
            // Incrementa a pontuação
            score += 10;
        }
    }
    // Atualiza o tabuleiro
    drawBoard();

    // Atualiza a pontuação
    scoreElement.innerHTML = "Pontuação: " + score;
}

// Função de colisão
Piece.prototype.collision = function(x, y, piece) {
    for (let r = 0; r < piece.length; r++) {
        for (let c = 0; c < piece.length; c++) {
            // Se o quadrado está vazio, pula
            if (!piece[r][c]) {
                continue;
            }
            // Coordenadas da peça após o movimento
            let newX = this.x + c + x;
            let newY = this.y + r + y;

            // Condições
            if (newX < 0 || newX >= COL || newY >= ROW) {
                return true; // Colisão com paredes ou fundo
            }
            // Pula newY < 0; board[-1] quebraria o jogo
            if (newY < 0) {
                continue;
            }
            // Verifica se já existe uma peça bloqueada no local
            if (board[newY][newX] != VACANT) {
                return true;
            }
        }
    }
    return false;
}

// Peça inicial
let p = randomPiece();

// Loop do jogo
let dropStart = Date.now();
let gameOver = false;

function drop() {
    let now = Date.now();
    let delta = now - dropStart;
    if (delta > 1000) { // Cai a cada 1 segundo
        p.moveDown();
        dropStart = Date.now();
    }
    if (!gameOver) {
        requestAnimationFrame(drop);
    }
}

drop();

// Controla a peça
document.addEventListener("keydown", CONTROL);

function CONTROL(event) {
    if (gameOver) return; // Não permite controlo se o jogo acabou

    if (event.keyCode == 37) { // Seta esquerda
        p.moveLeft();
        dropStart = Date.now(); // Reinicia o temporizador de queda após movimento manual
    } else if (event.keyCode == 38) { // Seta cima (rodar)
        p.rotate();
        dropStart = Date.now();
    } else if (event.keyCode == 39) { // Seta direita
        p.moveRight();
        dropStart = Date.now();
    } else if (event.keyCode == 40) { // Seta baixo (mover para baixo mais rápido)
        p.moveDown();
        // Não é necessário reiniciar dropStart aqui, pois moveDown lida com sua própria lógica
    }
}

